<?php

// usa função logout() presente em auth.php
logout();
header('Location: /');