<?php

class Emprestimo
{

    protected $conn;

    public function __construct()
    {
        $this->conn = connection();
    }

    public function all()
    {
        return $this->conn->query("SELECT * FROM emprestimos");
    }


    public function save (int $user_id, int $book_id) {
        
        $query = "INSERT INTO emprestimos(user_id, book_id)".
            " VALUES($user_id, $book_id)";

        $result = $this->conn->exec($query);
    }
    
}
